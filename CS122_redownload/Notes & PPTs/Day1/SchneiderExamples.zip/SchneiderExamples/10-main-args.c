/* main() actually has two arguments that pertain to what was entered
 * on the command line.  The first argument is a count of the number
 * of terms, the second argument is an array of pointers to chars (a
 * somewhat sophisticated thing which allows us to have an array of
 * strings of different lengths).
 */

#include <stdio.h>

int main(int argc, char *argv[]) {
  int i;

  printf("argc = %d\n", argc);

  for (i=0; i<argc; i++)
    printf("%i %s\n", i, argv[i]);

  return 0;
}
