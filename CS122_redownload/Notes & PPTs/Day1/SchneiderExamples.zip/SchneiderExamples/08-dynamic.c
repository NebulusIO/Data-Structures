/* Demonstration of dynamic memory allocation.  We can create an array
 * of arbitrary size at run-time, i.e., the user specifies the size
 * when the program is run.  sizeof() operator returns the size, in
 * bytes, of the type of data given as an argument.
 */

#include <stdio.h>
#include <stdlib.h>  // For malloc(), the memory allocation function.

int main() {
  int i, size, *ip;

  printf("Enter the size: ");
  scanf("%d", &size);

  printf("int, float, char, double: %lu %lu %lu %lu\n",
	 sizeof(int), sizeof(float), sizeof(char), sizeof(double));
  printf("ip: %lu\n", sizeof(ip));

  ip = (int *)malloc(size * sizeof(int));
  if (ip == NULL)
    exit(-1);

  for (i=0; i<size; i++)
    ip[i] = i * 3;

  for (i=0; i<size; i++)
    printf("ip[%d] = %d\n", i, ip[i]);

  return 0;
}
  
