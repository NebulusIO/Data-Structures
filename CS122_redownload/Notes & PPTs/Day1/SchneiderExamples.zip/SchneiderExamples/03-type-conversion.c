/* Here we have our own function and provide the prototype -- so this
 * is working/valid code.  Our function returns a value (a float), but
 * we are always free to ignore return values.
 *
 * Note that the compiler will convert the int argument given to the
 * function to a double since the function says it takes an double
 * argument.  Also, although the function returns a float, it is
 * assigned to an int variable and thus the fractional part is lost.
 */

#include <stdio.h>
#define ANSWER 42

// We need a "prototype" to tell the compiler about our function(s).
float say_hello(double);

int main() {
  int i=ANSWER;

  i = say_hello(i);

  printf("back in main. i = %d\n", i);

  return 0;
}

float say_hello(double a) {

  printf("hello! %f\n", a);
  return a + 37.123;
}
