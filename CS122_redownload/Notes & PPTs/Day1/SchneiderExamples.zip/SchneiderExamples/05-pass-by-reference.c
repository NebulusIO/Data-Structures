/* Demonstration of pass by reference.  This requires pointers.  We
 * can force pass by reference.  The two important operators pertinent
 * to working with pointers are:
 *
 *     & = "address of" operator
 *     * = dereference operator (value at the memory location...)
 */

#include <stdio.h>

void change_ij(int*, int*);  // function prototype

int main() {
  int i=10, j=42;

  printf("in main. i = %d, j = %d\n", i, j);

  change_ij(&i, &j);

  printf("in main. i = %d, j = %d\n", i, j);

  return 0;
}

void change_ij(int* i, int* k) {
  // i, by itself is a pointer (memory location where
  //    an integer is stored).
  *i = *i + 2;
  *k += 10;
  printf("change_i: %d %d\n", *i, *k);
  printf("change_i: %p %p\n", i, k);

}
