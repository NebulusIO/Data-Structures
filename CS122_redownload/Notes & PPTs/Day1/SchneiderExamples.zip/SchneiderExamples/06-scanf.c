/* Now that we understand pass by reference, we can better understand
 * the syntax used with scanf(), the function in C we use to read in
 * values.
 */

#include <stdio.h>

int main() {
  int i;
  float a;
  double x;

  printf("Enter i, a, and x: ");
  scanf("%d %f %lf", &i, &a, &x);

  printf("i, a, x: %d %f %f\n", i, a, x);

  return 0;
}
