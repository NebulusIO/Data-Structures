/* Demonstration that C is, by default, "pass by value".  If we
 * include a variable as an argument to function, that function can
 * only change its own copy of the variable.  It cannot change the
 * value of the variable back in the calling function.  Don't let
 * similar variable names fool you!  The i in main() is different from
 * the i in change_ij() -- they live in different scopes.
 */

#include <stdio.h>

void change_ij(int, int);  // function prototype

int main() {
  int i=10, j=42;

  printf("in main. i = %d, j = %d\n", i, j);

  change_ij(i, j);

  printf("in main. i = %d, j = %d\n", i, j);

  return 0;
}

void change_ij(int i, int j) {

  i = i + 2;
  j += 10;
  printf("change_i: %d %d\n", i, j);

}
