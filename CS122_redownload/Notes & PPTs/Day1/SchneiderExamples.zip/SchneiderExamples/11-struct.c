/* Demonstration of a struct -- a way to bundle information together
 * in a single named collection.  Here we also use a typedef statement
 * provide a more convenient way of creating person structs.  Without
 * this, we have to write "struct person" instead of simply Person.
 */

#include <stdio.h>
#include <string.h>

typedef struct person {
  char name[20];
  int age;
} Person;

int main() {
  Person bob;

  printf("What is bob's name? "); // trick questions?
  scanf("%s", bob.name);
  bob.age = 50;

  printf("%s %d\n", bob.name, bob.age);

  return 0;
}
