/* Demonstration of creating our own function.  Here we create the
 * function say_hello().  The following code is broken in that there
 * compiler doesn't know enough about our function when it sees it in
 * main().  There are two ways to fix this: provide a function
 * prototype or define the function before using it.
 * 
 * This code also demonstrates the use of the #define preprocessor
 * directive.  This #define statement tells the compiler to replace all
 * occurrences of the string ANSWER with 42.  There are no semicolons
 * at the end of the preprocessor directives.
 *
 * With the gcc compiler, we can see the output of the preprocessor by
 * using:
 *
 *         gcc -E 01-hello.c
 */

#include <stdio.h>

#define ANSWER 42

int main() {
  int i=ANSWER;

  say_hello(i);

  printf("back in main\n");

  return 0;
}

void say_hello(double a) {

  printf("hello! %f\n", a);

}
