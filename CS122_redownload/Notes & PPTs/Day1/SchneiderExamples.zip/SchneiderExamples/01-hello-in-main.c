/* Obtaining output with the printf() function.  Although printf() is
 * part of the standard C library, the compiler needs additional
 * information about it before it can compile the code.  For printf(),
 * this information is in the file stdio.h which we must include with
 * the preprocessor directive #include.
 *
 * With the gcc compiler, we can see the output of the preprocessor by
 * using:
 *
 *         gcc -E 01-hello.c
 */

#include <stdio.h>

int main() {
  int x=42;  // can initialize variables when declared

  // printf() in C is similar to printf() in Java
  printf("hello! %d\n", x);

  return 0;
}
