/* Demonstration of the similarity between pointers and arrays.  In
 * addition to "dereferencing" a pointer with *, we can use brackets
 * and an integer "offset" within the brackets.  All the following
 * expressions are equivalent:
 *
 *     *p  <=>   p[0]   <=>  *(p + 0)
 *
 * If we want the value at the location that is offset n from the
 * memory location to which "p" currently points, we can write either
 * of the following:
 *
 *     p[n]   <=>  *(p + n)
 *
 * An array name without the brackets is the address where the array
 * starts (i.e., essentially a pointer, but we can't assign a value to
 * it).
 */

#include <stdio.h>
#define SIZE 10

int main() {
  int i, k[SIZE], *ip;

  for (i=0; i<SIZE; i++)
    k[i] = i * 3;

  ip = k;   // pointer points to start of array
  for (i=0; i<SIZE; i++)
    printf("k[%d] = %d\n", i, ip[i]);

  // %p is the format specifier for a pointer.
  printf("%p %p, %d %d\n", k, &k[0], *k, k[0]);

  return 0;
}
  
