/* The smallest possible valid C program.  We must have the function
 * main().  The return value is the exit status of the program.  Often
 * the exit status is ignored.
 * 
 * As an aside, under Unix and Linux (note that Macs are Unix
 * machines), you can see the exit status of the most recently run
 * program by issuing the following command from the "command line":
 *
 *    echo $?
 *
 * This also assumes the program was run from the command line.
 */

int main() {
  return 122;
}
