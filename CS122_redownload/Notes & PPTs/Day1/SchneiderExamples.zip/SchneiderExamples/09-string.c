/* Demonstration of a character array which is how we get strings in
 * C.  To be a legitimate string, the last character in the string
 * must be the null character '\0' (this doesn't have to be the last
 * character in the array -- it can come before the end of the array
 * if the string is shorter than the length of the arra).
 */

#include <stdio.h>

int main() {
  char s[20]; // string can hold up to 19 "regular" characters

  printf("Enter string: ");
  scanf("%[^\n]s", s);  // trick to read until the newline character
  printf("             11111111112\n");
  printf("    12345678901234567890\n");
  printf("s = %s|||\n", s);

  s[6] = '\0';

  printf("             11111111112\n");
  printf("    12345678901234567890\n");
  printf("s = %s|||\n", s);

  printf("s = %s|||\n", &s[7]);

  return 0;
}
