#ifndef DATA_PROC_H
#define DATA_PROC_H

#include <stdio.h>
#include <string.h>

// precondition: file has been opened successfully!
//               line points to contiguous memory!
char * readLine(FILE *infile, char *line);


#endif