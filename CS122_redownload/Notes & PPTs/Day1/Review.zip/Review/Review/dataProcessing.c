#include "dataProcessing.h"

char * readLine(FILE *infile, char *line)
{
	//char line[200] = "";

	fgets(line, 200, infile);

	return line;
}