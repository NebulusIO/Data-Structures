#include "dataProcessing.h"

int main(void)
{
	FILE *infile = NULL;
	char pLine[200] = "";

	infile = fopen("StudentRecords.csv", "r");

	if (infile == NULL)
	{
		printf("WARNING: Could not open %s\n", "StudentRecords.csv");
	}
	else // opened file successfully; process data
	{
		//strcpy (readLine(infile));
		readLine(infile, pLine);
		puts(pLine);

		fclose(infile);
	}
		
	return 0;
}