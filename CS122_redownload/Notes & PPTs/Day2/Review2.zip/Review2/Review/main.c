#include "dataProcessing.h"

int main(void)
{
	FILE *infile = NULL;
	char pLine[200] = "", *pToken = NULL;
	Student records[100] = { {""}};
	int count = 0;

	infile = fopen("StudentRecords.csv", "r");

	if (infile == NULL)
	{
		printf("WARNING: Could not open %s\n", "StudentRecords.csv");
	}
	else // opened file successfully; process data
	{
		//strcpy (readLine(infile));
		// last
		while (!feof (infile))
		{
		readLine(infile, pLine);
		pToken = strtok(pLine, ",");
		strncpy(records[count].last, pToken, 25);
		puts(records[count].last);

		// first
		pToken = strtok(NULL, ",");
		strncpy(records[count].first, pToken, 25);
		puts(records[count].first);

		// major
		pToken = strtok(NULL, ",");
		strncpy(records[count].major, pToken, 5);
		puts(records[count].major);

		// hobby
		pToken = strtok(NULL, ",");
		strncpy(records[count].hobby, pToken, 15);
		puts(records[count].hobby);

		++count;
		}

	//	puts(pToken);
	//	puts(pLine);

		fclose(infile);
	}
		
	return 0;
}