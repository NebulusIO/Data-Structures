#ifndef DATA_PROC_H
#define DATA_PROC_H

#include <stdio.h>
#include <string.h>

typedef struct student
{
	char first[25];
	char last[25];
	char major[5];
	char hobby[15];
} Student;

// precondition: file has been opened successfully!
//               line points to contiguous memory!
char * readLine(FILE *infile, char *line);


#endif