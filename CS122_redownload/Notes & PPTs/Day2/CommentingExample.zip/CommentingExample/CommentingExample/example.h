/*******************************************************************************
 * Programmer: Andrew S. O'Fallon                                              *
 * Class: CptS 121; Lab Section 0                                              *
 * Programming Assignment: Example                                             *
 * Date:                                                                       *
 *                                                                             *
 * Description: This program calculates statistics on student records          *
 *              read in from a file.                                           *
 *                                                                             *
 * Relevant Formulas: Refer to each function definition.                       *
 *                                                                             *
 * Format of record in input file (input.dat): 12345678 (ID int)               *
 *                                             3.78     (gpa double)           *
 *									           3        (class standing int)   *
 *									           20.5     (age double)           *
 *                                                                             *                                         
 * Format of output file (output.dat): See problem specification.              *
 ******************************************************************************/

#ifndef EXAMPLE_H
#define EXAMPLE_H

#include <stdio.h>  /* Needed for fscanf ( ), fprintf ( ), fopen ( ), etc. */
#include <math.h>	/* Needed for sqrt ( ) */
#include <stdlib.h> /* Needed for exit ( ) */

/* Function prototypes */

void run_app (void);

double read_double (FILE *infile);
int read_integer (FILE *infile);

double calculate_sum (double number1, double number2, double number3, double number4, double number5);
double calculate_mean (double sum, int number);
double calculate_deviation (double number, double mean);
double calculate_variance (double deviation1, double deviation2, double deviation3, double deviation4, double deviation5, int number);
double calculate_standard_deviation (double variance);

double find_max (double number1, double number2, double number3, double number4, double number5);
double find_min (double number1, double number2, double number3, double number4, double number5);

void print_double (FILE *outfile, double number);

#endif