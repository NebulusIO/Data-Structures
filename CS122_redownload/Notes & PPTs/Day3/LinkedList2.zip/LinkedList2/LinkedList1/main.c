#include "LinkedList.h"

int main(int argc, char *argv[])
{
	List carCollection = {NULL};

	initList(&carCollection); // initialize the car collection to be empty

	return 0;
}