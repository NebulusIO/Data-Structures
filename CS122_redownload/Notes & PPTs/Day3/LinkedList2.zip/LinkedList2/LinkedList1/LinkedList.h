#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct car
{
	char make[10]; // 10 Bytes for the make
	char *pModel;  // 4 Bytes for an address to the actual string storage
	int year;
} Car;

typedef struct node
{
	Car vehicle;
	struct node *pNext; // next node, which implies next car in collection
} Node;

typedef struct list
{
	Node *pHead; // start from beginning of collection
} List;

void initList(List *pCollection); // initialize the collection to empty
Node *makeNode(Car newCar);


#endif