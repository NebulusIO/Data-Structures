#include "LinkedList.h"

void initList(List *pCollection)
{
	pCollection->pHead = NULL; // initialized the list
}