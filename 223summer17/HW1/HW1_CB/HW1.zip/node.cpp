#include "node.h"


StackNode::StackNode (int newData) //constructor, initialize newData to 0;
{
    mData = newData;
    pNext = nullptr;
}


StackNode::StackNode (StackNode &copy) //copy constructor, pass by value
{
   // this->setData() = copy.getData();
    //this->setNextPtr() = copy.getNextPtr();
}

StackNode::~StackNode () //deconstructor
{
    delete (this);
}

    //getters

int StackNode::getData() const //returns data
{
    return this->mData;
}
StackNode* StackNode::getNextPtr() const
{
    return this->pNext;
}

    //setters
void StackNode::setData(const int newData) //modify StackNode's data to newData
{
    this->mData = newData;
}


void StackNode::setNextPtr(const StackNode* pNewNext) //modify StackNode's next ptr
{
    const StackNode *pNext = pNewNext;
}
