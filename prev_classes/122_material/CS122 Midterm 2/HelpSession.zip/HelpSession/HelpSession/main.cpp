#include <iostream>

#include "ExercisePlan.h"
#include "TestExercisePlan.h"
using std::cin;
using std::cout;
using std::endl;

int main (void)
{
	ExercisePlan e1 (10);
	TestExercisePlan t;

	t.testExercisePlanDestructor ();
	t.testExercisePlanCopyConstructor (e1);
	t.testExercisePlanAssignmentOperator ();

	//cout // ostream
	//cin // istream

	return 0;
}