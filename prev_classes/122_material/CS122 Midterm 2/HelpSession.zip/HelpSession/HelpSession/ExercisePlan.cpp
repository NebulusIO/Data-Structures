#include "ExercisePlan.h"

ExercisePlan::ExercisePlan (int newGoalSteps, int newCurrentSteps,
			          string newPlanName, string newDataCreated)
{
	this->mCurrentSteps = newCurrentSteps;
	this->mGoalSteps = newGoalSteps;
	this->mDataCreated = newDataCreated;
	this->mPlanName = newPlanName;
}

ExercisePlan::ExercisePlan (ExercisePlan &copy)
{
	// shallow
	this->mCurrentSteps = copy.mCurrentSteps;
	this->mGoalSteps = copy.mGoalSteps;
	this->mDataCreated = copy.mDataCreated;
	this->mPlanName = copy.mPlanName;
}

ExercisePlan::~ExercisePlan ()
{
	// does nothing
	cout << "Inside Exercise Plan's destructor" << endl;
}


ExercisePlan & ExercisePlan::operator= (ExercisePlan &rhs)
{
	//ExercisePlan result; // ExercisePlan * pE = &result

	// did not check for self-assignment
	this->mCurrentSteps = rhs.mCurrentSteps;
	this->mGoalSteps = rhs.mGoalSteps;
	this->mDataCreated = rhs.mDataCreated;
	this->mPlanName = rhs.mPlanName;

	//return result; // return pE
	return *this;
}