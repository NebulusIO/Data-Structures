#include "TestExercisePlan.h"

void TestExercisePlan::testExercisePlanDestructor ()
{
	ExercisePlan e2;
}

void TestExercisePlan::testExercisePlanCopyConstructor 
	(ExercisePlan passByValue)
{
}


void TestExercisePlan::testExercisePlanAssignmentOperator ()
{
	ExercisePlan e1, e2(100, 5);

	e1 = e2; // same as e1.operator= (e2);
}