#ifndef EXERCISE_PLAN_H
#define EXERCISE_PLAN_H

// #pragma once

#include <iostream>
#include <string>

using std::cin;
using std::cout;
using std::string;
using std::endl;

class ExercisePlan
{
	public:
		ExercisePlan (int newGoalSteps = 0, int newCurrentSteps = 0,
			          string newPlanString = "", string newDataCreated = "");
		
		ExercisePlan (ExercisePlan &copy);

		~ExercisePlan ();

		ExercisePlan & operator= (ExercisePlan &rhs);



	private:
		//data members
		int mGoalSteps;
		int mCurrentSteps;
		string mPlanName;
		string mDataCreated;
};


#endif