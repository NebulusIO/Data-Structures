#pragma once

#include <iostream>
#include <string>

#include "ExercisePlan.h"

using std::cin;
using std::cout;
using std::string;
using std::endl;

class TestExercisePlan
{
	public:
		void testExercisePlanDestructor ();
		void testExercisePlanCopyConstructor (ExercisePlan passByValue);
		void testExercisePlanAssignmentOperator ();
};