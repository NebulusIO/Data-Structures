#ifndef MANAGER_H
#define MANAGER_H

#include <iostream>
#include <string>

#include "Employee.h"

using std::cout;
using std::cin;
using std::endl;
using std::string;

// Manager is a derived class, it's derived from Employee - need to complete the inheritance in class
class Manager : public Employee
{
	public:
		Manager (string newName = "", double newPayRate = 0.0, double newHours = 0, bool newSalariedEmployee = false);
		~Manager ();

		// With inheritance, we should NOT have to redefine
		// many of the functions that we find in the Employee
		// class!

		//string getName ();
		//double getPayRate ();
		//double getHours ();

		//void setName (string newName);
		//void setPayRate (double newPayRate);
		//void setHours (double newHours);

		double calculatePay ();


	private:
	/*	string mName;
		double mPayRate;
		double mHours;*/
		bool mIsSalaried;
	
};

#endif