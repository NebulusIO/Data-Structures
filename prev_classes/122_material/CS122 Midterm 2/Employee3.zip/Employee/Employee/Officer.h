#pragma once

#include <iostream>
#include <string>

#include "Manager.h"

using std::cout;
using std::cin;
using std::endl;
using std::string;

class Officer : public Manager
{
	// What happens if we don't specify a constructor for
	// Officer?
public:
	Officer (int newNumShares = 100);


	void setNumShares (int newNumShares);
	int getNumShares ();

	private:
		int mNumShares;
};