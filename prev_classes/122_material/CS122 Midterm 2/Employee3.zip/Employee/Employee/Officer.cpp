#include "Officer.h"

Officer::Officer (int newNumShares)
{
	mNumShares = newNumShares;
}


void Officer::setNumShares (int newNumShares)
{
	mNumShares = newNumShares;
}
	
int Officer::getNumShares ()
{
	return mNumShares;
}