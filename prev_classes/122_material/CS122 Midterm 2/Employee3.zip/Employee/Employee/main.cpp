// AO

// This example introduces inheritance. Note that
// the Manager class is derived from the Employee class

#include <iostream>
#include <string>

// Inheritance starter code! Not yet complete!

#include "Employee.h"
#include "Manager.h"
#include "Officer.h"

int main (void)
{
	// paid / 2 weeks
	Manager m1 ("manager", 2000, 200, true);
	Manager m2 ("Thomas", 50, 80, false);
	Officer o1;

	o1.setHours (25); // setHours () is inherited from Employee
	o1.setPayRate (100); // setPayRate () is inherited from Employee also
	cout << "o1: " << o1.calculatePay () << endl;

	/*cout << "m1: " << m1.calculatePay () << endl;
	cout << "m2: " << m2.calculatePay () << endl;*/


	return 0;
}