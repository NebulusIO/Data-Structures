#include "Manager.h"

Manager::Manager (string newName, double newPayRate, double newHours, bool newSalariedEmployee) : Employee (newName, newPayRate, newHours)
{
	this->mIsSalaried = newSalariedEmployee;
}


Manager::~Manager ()
{
	cout << "Inside Manager destructor" << endl;
}

double Manager::calculatePay ()
{
	double pay = 0.0;

	if (!(this->mIsSalaried)) // hourly employee?
	{
		pay = Employee::calculatePay ();
	}
	else // salaried employee
	{
		// Did we define a getPayRate () in Manager? No!
		// But, we can access the getPayRate inherited from
		// Employee!
		// Using getPayRate () is necessary if mPayRate
		// is private in the Employee base class.
		// If we make the data members protected,
		// then we don't need to use the getters inside
		// of the Manager. 
		//pay = getPayRate (); //this->mPayRate;
		// we now made data members of Employee protected
		pay = this->mPayRate; 
	}

	return pay;
	//calculatePay ();
}