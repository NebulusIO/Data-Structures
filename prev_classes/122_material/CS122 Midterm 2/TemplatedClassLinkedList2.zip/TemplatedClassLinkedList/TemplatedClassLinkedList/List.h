// Andrew S. O'Fallon
// This example implements some of the methods for a linked list class that we implemented in lecture
// This illustrates how to use templated container classes
// This example provides limited comments

#ifndef LIST_H
#define LIST_H

#include <iostream>
#include <string>
#include "ListNode.h"

using std::cout;
using std::cin;
using std::string;
using std::ostream;
using std::endl;

// Note List is not a friend of ListNode; must use setters/getters to access the data in ListNode

template <class T>
class List
{
	

	public:

		List ();
		List (List<T> & copyList); // deep copy
		~List ();

		List<T> & operator= (const List<T> &rhs);

		ListNode<T> * getStartPtr ();
		void setStartPtr (ListNode<T> *start);
		int getSize ();
		void setSize (int size);

		bool insertAtFront (const T &newData); // discuss const & as an option
		bool deleteList (); // Destroy the list
		bool deleteNode (T &key);

	private:

		ListNode<T> *mStartPtr;
		int mSize;
		//ListNode<T> mlistArray[100]; // This is an alternative approach
};


// did not make this overloaded operator a friend to the ListNode class, must use getters!
template <class T>
ostream & operator<< (ostream &output, List<T> &l)
{
	ListNode<T> *tempPtr = l.getStartPtr ();

	while (tempPtr != NULL)
	{
		output << tempPtr -> getData ()<< " ";
		tempPtr = tempPtr -> getNextPtr ();
	}

	output << endl;

	return output;
}

template <class T>
List<T>::List ()
{
	mStartPtr = NULL;
	mSize = 0;
}

template <class T>
List<T>::List (List<T> &copyList) // deep copy --> make completely new nodes for the list
{
	ListNode<T> *tempPtr = NULL, *memPtr = NULL, *currentPtr = NULL;

	mSize = 0;

	tempPtr = copyList.getStartPtr (); // Starting point for list
	                                   // that we want to copy
	while (tempPtr != NULL)
	{
		memPtr = new ListNode (tempPtr -> getData ());
		// Assume we are able to allocate memory successfully

		if (mSize == 0) // "This" list object is currently empty
		{
			mStartPtr = memPtr;
			currentPtr = mStartPtr;
		}
		else
		{
			currentPtr -> setNextPtr (memPtr);
			currentPtr = currentPtr -> getNextPtr ();
		}

		tempPtr = tempPtr -> getNextPtr ();

		mSize++;
	}
}

// The destructor is invoked when a List object goes out of scope --> should free the memory allocated to the nodes!
template <class T>
List<T>::~List ()
{
	deleteList ();
}

template <class T>
List<T> & List<T>::operator= (const List<T> &rhs)
{
	if (this != &rhs)
	{
		// Not complete
	}

	return *this;
}

template <class T>
ListNode<T> * List<T>::getStartPtr ()
{
	return mStartPtr;
}

template <class T>
void List<T>::setStartPtr (ListNode<T> *startPtr)
{
	mStartPtr = startPtr;
}

template <class T>
int List<T>::getSize ()
{
	return mSize;
}

template <class T>
void List<T>::setSize (int size)
{
	mSize = size;
}

template <class T>
bool List<T>::insertAtFront (const T &newData)
{
	bool success = false;
	ListNode<T> *pMem = new ListNode<T> (newData);
	if (pMem != NULL)
	{
		pMem->setNextPtr (this->mStartPtr);
		this->mStartPtr = pMem;

	
		success = true;
	}

	//if (this->mStartPtr == NULL) // list is empty
	//{
	//	this->mStartPtr = new ListNode (newData);
	//	if (this->mStartPtr != NULL)
	//	{
	//		success = true;
	//	}

	//}
	//else // list is not empty
	//{
	//	ListNode<T> *pMem = new ListNode (newData);
	//	pMem ->setNextPtr (this->mStartPtr);
	//	this->mStartPtr = pMem;
	//	if (pMem != NULL)
	//	{
	//		success = true;
	//	}
	//}
	
	return success;
	
}

template <class T>
bool List<T>::deleteList ()
{
	ListNode<T> *tempPtr = NULL, *deletePtr = NULL;
	bool success = false;

	tempPtr = this -> mStartPtr;

	while (tempPtr != NULL)
	{
		deletePtr = tempPtr;
		tempPtr = tempPtr -> getNextPtr ();
		delete deletePtr;
		success = true;
	}

	return success;
}

template <class T>
bool List<T>::deleteNode (T &key)
{
	bool success = false;
	ListNode<T> *pCur = this->mStartPtr, *pPrev = NULL;

	while ((pCur != NULL) && (pCur->getData () != key))
	{
		pPrev = pCur;
		pCur = pCur->getNextPtr ();
	}

	if (pCur != NULL) // found the key in the list
	{
		if (pPrev != NULL) // not deleting first node
		{
			pPrev->setNextPtr (pCur->getNextPtr ());
			delete pCur;
		}
		else // deleting the first node
		{
			this->mStartPtr = pCur->getNextPtr ();
			delete pCur;
		}

		success = true;
	}

	// will complete in lecture
	return success;
	
}

#endif