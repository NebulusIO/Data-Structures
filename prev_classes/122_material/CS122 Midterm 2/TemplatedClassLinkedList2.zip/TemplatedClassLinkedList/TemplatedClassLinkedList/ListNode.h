// Andrew S. O'Fallon
// This example implements some of the methods for a linked list class that we implemented in lecture
// This illustrates how to use templated container classes
// This example provides limited comments 

#ifndef LISTNODE_H
#define LISTNODE_H

#include <iostream>
#include <string>

using std::cout;
using std::cin;
using std::string;

template <class T>
class ListNode
{
	// friend ostream & operator<< (ostream &output, List<T> &l);
	public:
		ListNode (T newData, ListNode<T> *newPtr = NULL);
		ListNode (ListNode<T> &newNode);
		~ListNode ();

		ListNode & operator= (const ListNode<T> &rhs);

		T getData (void) const;
		void setData (T newData);

		ListNode<T> * getNextPtr (void) const;
		void setNextPtr (ListNode<T> *nextPtr);

	private:
		T mData;
		ListNode<T> *mNextPtr;
};

template <class T>
ListNode<T>::ListNode (T newData, ListNode<T> *newPtr)
{
	this -> mData = newData;
	this -> mNextPtr = newPtr;
}

template <class T>
ListNode<T>::ListNode (ListNode<T> &newNode)
{
	// Shallow copy
	this -> mData = newNode.mData;
	this -> mNextPtr = newNode.mNextPtr;

	// Deep copy
	// same as shallow copy for this class
}

template <class T>
ListNode<T>::~ListNode ()
{
	// All deleting will be done by List's destructor
}

template <class T>
ListNode<T> & ListNode<T>::operator= (const ListNode<T> &rhs) 
{
	if (this != &rhs)
	{
		this -> mData = rhs.mData;
		this -> mNextPtr = rhs.mNextPtr;
	}

	return *this;
}

template <class T>
T ListNode<T>::getData (void) const
{
	return mData;
}

template <class T>
void ListNode<T>::setData (T newData)
{
	mData = newData;
}

template <class T>
ListNode<T> * ListNode<T>::getNextPtr (void) const
{
	return mNextPtr;
}

template <class T>
void ListNode<T>::setNextPtr (ListNode<T> *nextPtr)
{
	mNextPtr = nextPtr;
}

#endif