// some basic file processing

#include <iostream>
#include <fstream>
#include <string>
#include <cstring> // use strtok () instead to split a string?

using std::cin;
using std::cout;
using std::endl;

using std::string;
using std::ifstream;
using std::ofstream;
using std::ios;

int main (void)
{
	// ostream cout
	// istream cin

	// ifstream - input file stream - reading
	// ofstream - output file stream - writing
		
	cout << "Enter a filename: ";
	string filename;
	cin >> filename;

	ifstream input;
	input.open (filename, std::ios::in);  // out for read mode
	
	//ifstream input2 (filename.c_str (), std::ios::in); // c like string for filename

	string str[100];
	char myArray[100];
	int i = 0;
	// while !feof ()
	while (!input.eof ())
	{
		//input >> str; // 
		// how to get a line with space?
		input.getline (myArray, 100, ','); // will read in a string up to the ','
		str[i] = myArray; // place the char * token into an array of strings
		// you could now store each field into a field in
		// linked node
		cout << "str[" << i << "]:" << str[i] << endl;
		i++;
	}




	return 0;
}