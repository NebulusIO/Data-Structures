// AO

// This example introduces inheritance. Note that
// the Manager class is derived from the Employee class

#include <iostream>
#include <string>

// Inheritance starter code! Not yet complete!

#include "Employee.h"
#include "Manager.h"

int main (void)
{
	// paid / 2 weeks
	Manager m1 ("manager", 2000, 200, true);
	Manager m2 ("Thomas", 50, 80, false);

	cout << "m1: " << m1.calculatePay () << endl;
	cout << "m2: " << m2.calculatePay () << endl;


	return 0;
}