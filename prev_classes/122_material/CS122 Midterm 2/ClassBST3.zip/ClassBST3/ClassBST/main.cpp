// This project will define a BST container class; 
// will use this class with another class we 
// created (Rational)

// History: 10/12 - Completed insert () and destroyTree () in
//                  class! I filled in the functions for
//                  inOrderTraversal (), preOrderTraversal (),
//                  and postOrderTraversal () after class.
//                  Recall, class BST is a friend of class BSTNode,
//                  which enables a BST to access the private
//                  data members of a BSTNode directly without
//                  calling public functions (i.e. setters, getters,
//                  etc.) Please pay close attention to the
//                  way BSTNode private data members are accessed
//                  in functions that are implemented in BST.

#include "BST.h"

int main (void)
{
	Rational r1 (5, 3), r2 (5, 2), r3 (5, 4), r4 (10, 5),
		     r5 (1, 3), r6 (1, 4), r7 (1, 2), r8 (6, 2);
	BST t;

	// Could also create an array of Rationals and loop through
	// them!
	t.insert (r1);
	t.insert (r2);
	t.insert (r3);
	t.insert (r4);
	t.insert (r5);
	t.insert (r6);
	t.insert (r7);
	t.insert (r8);

	// run the different traversals
	cout << endl << "Inorder traversal: " << endl;
	t.inOrderTraversal ();
	cout << endl << "Preorder traversal: " << endl;
	t.preOrderTraversal ();
	cout << endl << "Postorder traversal: " << endl;
	t.postOrderTraversal ();

	// Note the destructor for the BST will be invoked upon
	// exiting main (), because the tree will go out of scope.
	// We placed a breakpoint inside of the destructor to show this!

	return 0;
}