#!/bin/sh

g++ -o dijkstra -g -std=c++0x main.cpp
